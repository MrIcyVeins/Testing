f x = g x + z
    where
        g x = 2*x
        z=x-1
        
t x = 2*x       
h x = t x + z
    where
         z=x-1
         
{-        
f2 x = g x + z
    where
        g x = 2*x
         z=x-1  -- eroare de la indentare
ghci> :t f
f :: Num a => a -> a

ghci> f 1.5
3.5
ghci> f 5
14


ghci> :t f3
f3 :: Int -> Int
ghci> f3 10
29


ghci> f3 10.5

<interactive>:37:4: error:
    * No instance for (Fractional Int) arising from the literal `10.5'       
         -}
f3 :: Int -> Int
f3 x = g x + z
    where
        g x = 2*x
        z=x-1
        
--maxim :: Integer -> Integer -> Integer
maxim x y = if ( x > y ) then x else y

maxim_c :: Char -> Char -> Char
maxim_c x y = if ( x > y ) then x else y

{-
ghci> maxim_c 'a' 'b'
'b'
-}

maxim3 x y z = maxim x (maxim y z )


maxim3_1 x y z = let u = (maxim y z) in (maxim x u )

{-
ghci> maxim3 10 9 (-5)
10


ghci> maxim3_1 10 9 (-5)
10

-}

maxim3_2 x y z =
  if (x >= y && x >= z)
    then x
    else
      if (y >= z)
        then y
        else z
		
maxim4 :: Integer -> Integer -> Integer -> Integer -> Integer
maxim4 x y z k = if ( x > y && x > z && x > k) 
	then x
    else if ( y > x && y > z && y > k) 
		then y 
		else if ( z > x && z > y && z > k) then z else k

maxim4_1 x y z t = let u = (maxim3_1 x y z) in (maxim u t)

max4 x y z v = let
                 u = maxim x y 
                 n = maxim z v
                in (maxim  u n)

test_maxim a b c d = (maxim4_1 a b c d)==(maxim4 a b c d)

{-
ghci> test_maxim (-1) 10 2 19
True

ghci> maxim4_1 1.5 2 7.9 10
10.0

ghci> maxim4 1.5 2 7.9 10

<interactive>:67:8: error:
    * No instance for (Fractional Integer)


ghci> test_maxim  1.5 2 7.9 10

<interactive>:68:13: error:
    * No instance for (Fractional Integer)	
	--am comentat signatura functie maxim care este folosita
	de functia maxim3 si maxim => se poate calcula maximul si pt numere fractionare
	-- maxim4 
-}


{- 
ghci> "ana" ++ "Vlad"
"anaVlad"

ghci> ["ana"] ++ ["Vlad"]
["ana","Vlad"]

ghci> ["ana"] ++ ["Vlad", "Simona"]
["ana","Vlad","Simona"]

ghci> :t "ana" ++ "Vlad"
"ana" ++ "Vlad" :: [Char]

ghci> :t ["ana"] ++ ["Vlad"]
["ana"] ++ ["Vlad"] :: [String]  <=> [ [Char] ] Echivalente


ghci> 'a': "na"
"ana"
ghci> 1 : [2,3,4]
[1,2,3,4]

-}

fact 0 = 1
fact n = n * fact (n-1)


-- fact2 n = n * fact2 (n-1)
-- fact2 0 = 1
{-   atentie la ordinea ecuatiilor!!!!!
ghci> fact2 0
*** Exception: stack overflow
-}

myInt = 5555555555555555555555555555555555555555555555555555555555555555555555555555555555555

double :: Integer -> Integer
double x = x+x


{-
ghci> f 5 = let x = 3 in x + x
ghci> f 5
6
ghci> f 3
*** Exception: <interactive>:121:1-24: Non-exhaustive patterns in function f

-}

{-
ghci> 5 `mod`2
1
ghci> True && False
False
ghci> True || False
True

ghci> not True
False

ghci> elem 1 [2,3,4]
False
ghci> elem 1 [2,3,1,4]
True
ghci> 1 `elem` [2,3,4]
False
ghci> 1 `elem` [2,3,1,4]
True
ghci> 3+5*4: [6]
[23,6]
ghci> 8-2+3: [2]
[9,2]
ghci> [23,6] ++ [9,2]
[23,6,9,2]
ghci> 2+5 == 7
True
ghci> True || (5==7)
True
ghci> True || 5==7
True
ghci> False || 5+2==7
True
ghci> True || True == False
True
ghci> (True || True) == False
False

ghci> [5] ++ [2]
[5,2]
ghci> [5,1] ++ [2,3]
[5,1,2,3]
ghci> 5 : [2,3]
[5,2,3]
ghci>
ghci> 5:[2,3] ++ [3,4]
[5,2,3,3,4]
ghci> [3,4] ++ 5 :[2,3]
[3,4,5,2,3]
ghci> [3,4] ++ 5 :[2,3] ++ [7,8]
[3,4,5,2,3,7,8]
ghci> [1,2,3] !! 0
1
ghci> [1,2,3] !! 1
2
ghci> [1,2,3] !! 2
3
ghci> [1,2,3] !! 3
*** Exception: Prelude.!!: index too large

ghci> div 7 3  --catul impartirii
2
ghci> mod 7 3  -- restul impartirii
1


ghci> 2 ^3
8
ghci> 2**3.5
11.313708498984761

ghci> add 2 3
13
ghci> add2 2 3
13
ghci>
ghci> add 2.5 3
15.25
ghci> add2 2.5 3

<interactive>:47:6: error:
    * No instance for (Fractional Int) arising from the literal `2.5'
    * In the first argument of `add2', namely `2.5'
      In the expression: add2 2.5 3
      In an equation for `it': it = add2 2.5 3
ghci> 2.5^2
6.25
ghci> 2.5*2.5
6.25

---------------EX3.2---------
-}


--a)
add x y = x^2 + y^2


add2 :: Int -> Int -> Int
add2 x y = x*x + y*y


--add3:: (Int, Int) -> Int
add3 (x,y) = x^2 + y^2  -- atentie la tipul functiei
--ghci> add3 (2,3)
--13

--b)
--paritate :: Int -> String
paritate x = if x `mod` 2 == 0 then "par" else "impar"

--ghci> paritate  (2^54)
--"par"


--c)
ex3 :: Int-> Int -> String	
ex3 x y = if x > y*2 then "da"
					  else "nu"

--comparexy :: Int -> Int -> Bool 
			  
comparexy x y = if (x > y * 2) 
				then True 
				else False
				
				{-
ghci> ex3 10 4
"da"
ghci> ex3 10 6
"nu"
ghci> comparexy  10 6
False
ghci> comparexy  10 4
True

comparexy :: (Ord a, Num a) => a -> a -> Bool



---Sectiuni
ghci> (-2) + 7
5
ghci> (-) 2 5
-3
ghci> ((-)2) 5
-3
ghci> 2-5
-3
ghci> (^2) 4
16
ghci> (4^) 3
64
ghci> (+) 2 3
5
ghci> (-) 2 3
-1
ghci> (subtract 2) 5
3

-}



----ex 3.3
--a)

f1 = (^2) 
g1 x y = f1 x + f1 y

{-
ghci> g1 2 3
13
ghci> g1 2 3 == add 2 3
True 
-}

--b)

pitagora1 :: Int -> Int -> Int -> String
pitagora1 x y z
    | x > y && x > z = if y*y + z*z == x*x
                       then "triunghiul e dreptunghic"
                       else "triunghiul nu e dreptunghic"
    | y > x && y > z = if x*x + z*z == y*y
                       then "triunghiul e dreptunghic"
                       else "triunghiul nu e dreptunghic"
    | z > x && z > y = if x*x + y*y == z*z
                       then "triunghiul e dreptunghic"
                       else "triunghiul nu e dreptunghic"
    | otherwise = "triunghiul nu e dreptunghic"


ex1 :: (Num a, Ord a) => a -> a -> a -> Bool
ex1 x y z
  | x >= y && x >= z = x^2 == y^2 + z^2
  | y >= x && y >= z = y^2 == x^2 + z^2
  | otherwise        = z^2 == x^2 + y^2
  
pitag = (^2)
pitagora2 x y z   
  | x <= 0 || y <= 0 || z <= 0 = False 
  | x >= y && x >= z = pitag y + pitag z == pitag x
  | y >= x && y >= z = pitag x + pitag z == pitag y 
  | otherwise = pitag x + pitag y == pitag z

tridrept :: Integer -> Integer -> Integer -> Bool
tridrept x y z 
    | (^2) x + (^2) y == (^2) z = True
    | (^2) x + (^2) z == (^2) y = True
    | (^2) z + (^2) y == (^2) x = True
    | otherwise = False
	
	
tridrept2 :: Integer -> Integer -> Integer -> Bool
tridrept2 x y z =(^2) x + (^2) y == (^2) z || (^2) x + (^2) z == (^2) y || (^2) z + (^2) y == (^2) x


pitagora x y z = (^2) x + (^2) y == (^2) z
etriunghi x y z = 
    pitagora x y z ||
    pitagora x z y ||
    pitagora y z x


--c)
poly :: (Double, Double, Double, Double) -> Double
poly (a, b, c, x) = a * x^2 + b * x + c  -- ARE un singur argument

exc :: Double -> Double -> Double -> Double -> Double
exc a b c x = a * (x^2) + b*x + c
 

{-
ghci> pitagora1 3 4 5
"triunghiul e dreptunghic"
ghci> pitagora1 3 4 6
"triunghiul nu e dreptunghic"
ghci> ex1 3 4 5 == pitagora 3 4 5
True
ghci> ex1 3 4 6 == pitagora 3 4 6
True

-}


--d)

eeny :: Integer -> String
eeny x
 | x `mod` 2 == 0 = "eeny"
 | otherwise = "meeny"
 
eeny2 :: Integer -> String 
eeny2 x = if even x then "eeny" else "meeny"

check :: Integer -> String
check n
    | even n = "eeny"
    | odd n = "meeny"

check2 :: Integer -> String
check2 n
    | even n = "eeny"
	| otherwise = "meeny"


fizzbuzz :: Integer -> String
fizzbuzz x
  | x `mod` 3 == 0 && x `mod` 5 == 0 = "FizzBuzz"
  | x `mod` 3 == 0 = "Fizz"
  | x `mod` 5 == 0 = "Buzz"
-- | otherwise = "" 


fizzbuzz2 :: Integer -> [Char]
fizzbuzz2 x 
    | mod x 3 == 0 && mod x 5 == 0 = "FizzBuzz"
    | mod x 3 == 0 = "Fizz"
    | mod x 5 == 0 = "Buzz"
    | otherwise = ""

fizzbuzz3 :: Integer -> String
fizzbuzz3 n = if (n `mod` 3 == 0) && (n `mod` 5 == 0) then "FizzBuzz"
             else if (n `mod` 5 == 0) then "Fizz"
             else if (n `mod` 3 == 0) then "Buzz"
             else ""
