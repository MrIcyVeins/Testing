import Data.List
{-
ghci> x = let x = 3 in x * 5
ghci> x
15

ghci> x = let x = 3, y = 4 in x * y

<interactive>:3:14: error: parse error on input `,'

ghci> x = let x = 3; y = 4 in x * y
ghci> x
12
-}

-- x = let 
    -- x = 3
    -- y = 4 
    -- in x * y

-- x=7 =>     Multiple declarations of `x'



func x = g x + g x + z
    where
        g x = 2*x
        z = x-1
        
h :: Int -> Int
h x 
  | x == 0    = 0
  | x == 1    = y + 1
  | x == 2    = y * y
  | otherwise = y
      where y = x*x

f x = case x of
         0 -> 0
         1 -> y + 1
         2 -> y * y
         _ -> y
    where y = x*x

myInt = 5555555555555555555555555555555555555555555555555555555555555555555555555555555555555

double :: Integer -> Integer
double x = x+x

triple :: Integer -> Integer
triple x = x+x+x

double_2 x = x * 2
triple_2 y = double_2 y + y

triple_3 y = double_2 (y + y)

penta :: Integer -> Integer
penta x = x+x+x+x+x

test x = (double x + triple x) == (penta x) 

testf x = (double x + double x) == (penta x) 

--maxim :: Integer -> Integer -> Integer
maxim x y = if (x > y) 
               then x 
          else y
               
max3 x y z = let
             u = maxim x y 
             in (maxim  u z)
             
maxim3 x y z =  if (x >= y) && ( x >= z)
                    then x 
                    else  
                        if ( y>=x) && (y>=z)
                            then y 
                            else z

-- max of three

maxOfThree :: Int -> Int -> Int -> Int
maxOfThree x y z
    | x >= y && x >= z = x
    | y >= x && y >= z = y
    | otherwise = z         

    
testmax x y = ((maxim x y) >= x) && ((maxim x y) >= y)


max4 x y z v = let
                 u = maxim x y 
                 n = maxim z v
                in (maxim  u n)

max4_1 x y w z = let a = max x y; b = max w z in max a b
{-

ghci> [1, 2]
[1,2]
ghci> [False, True]
[False,True]
ghci> [False, True, True && False]
[False,True,False]
ghci> [False, True, True && False, 1>2]
[False,True,False,False]
ghci> :t [False, True, True && False, 1>2]
[False, True, True && False, 1>2] :: [Bool]
ghci> :t "ana"
"ana" :: String
ghci> :t ["ana", "are", "mere"]
["ana", "are", "mere"] :: [String]
ghci> "ana" == ['a', 'n', 'a']
True
ghci> ["ana", "mere"] == [ ['a', 'n', 'a'], ['m', 'e', 'r', 'e']]
True

ghci> :t [True, 'a', "FP"]
<interactive>:1:8: error:


ghci> :t (True, 'a', "FP")
(True, 'a', "FP") :: (Bool, Char, String)

ghci> :t add2
add2 :: [a] -> [a] -> [a]
ghci> add2 [1,2,3] [4,5,6]
[1,2,3,4,5,6]
ghci> [1,2,3] ++ [4,5,6]
[1,2,3,4,5,6]
-}

add x y = x+y 
add2 x y = x ++ y 

dist :: ( Integer , Integer ) -> Integer
dist (x , y ) = abs (x-y )

fact 0 = 1
fact n = n * fact (n-1)

{-
fact2 n = n * fact2 (n-1)
fact2 0 = 1


ghci> fact 3
6
ghci> fact2 3
*** Exception: stack overflow
-}

ex1 a b = a^2 + b^2


ex1_2 :: (Int , Int) -> Int
ex1_2(a,b) = a^2 + b^2

ex_extra :: [Int] -> Int
ex_extra [] = 0
ex_extra (e:tl) = e^2 + ex_extra(tl)

functipatrate :: [Int]->[Int]
functipatrate []=[]
functipatrate (x:xs) = (x*x):functipatrate xs

ex2 a = if (a `mod` 2 ==0) then "par" else "impar"

ex3 a b = if ( a > 2*b) then True else False

ex3_1 a b = if ( a > 2*b) then "Adevarat" else "Fals"
               
ex3_2 a b = if ( a > b) then "Adevarat" else "Fals"            
               