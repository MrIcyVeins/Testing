-- la nevoie decomentati liniile urmatoare:  

-- import Data.Char
-- import Data.List


eeny :: Integer -> String
eeny = undefined

fizzbuzz :: Integer -> String
fizzbuzz = undefined

---------------------------------------------
-------RECURSIE: FIBONACCI-------------------
---------------------------------------------

fibonacciCazuri :: Integer -> Integer
fibonacciCazuri n
  | n < 2     = n
  | otherwise = fibonacciCazuri (n - 1) + fibonacciCazuri (n - 2)

fibonacciEcuational :: Integer -> Integer
fibonacciEcuational 0 = 0
fibonacciEcuational 1 = 1
fibonacciEcuational n =
    fibonacciEcuational (n - 1) + fibonacciEcuational (n - 2)

{-| @fibonacciLiniar@ calculeaza @F(n)@, al @n@-lea element din secvența
Fibonacci în timp liniar, folosind funcția auxiliară @fibonacciPereche@ care,
dat fiind @n >= 1@ calculează perechea @(F(n-1), F(n))@, evitănd astfel dubla
recursie. Completați definiția funcției fibonacciPereche.

Indicație:  folosiți matching pe perechea calculată de apelul recursiv.
-}
fibonacciLiniar :: Integer -> Integer
fibonacciLiniar 0 = 0
fibonacciLiniar n = snd (fibonacciPereche n)
  where
    fibonacciPereche :: Integer -> (Integer, Integer)
    fibonacciPereche 1 = (0, 1)
    fibonacciPereche n = undefined


tribonacci :: Integer -> Integer
tribonacci = undefined

binomial :: Integer -> Integer -> Integer
binomial = undefined

---------------------------------------------
----------RECURSIE PE LISTE -----------------
---------------------------------------------
semiPareRecDestr :: [Int] -> [Int]
semiPareRecDestr l
  | null l    = l
  | even h    = h `div` 2 : t'
  | otherwise = t'
  where
    h = head l
    t = tail l
    t' = semiPareRecDestr t


-- semiPareRec [0,2,1,7,8,56,17,18] == [0,1,4,28,9]

semiPareRecEq :: [Int] -> [Int]
semiPareRecEq [] = []
semiPareRecEq (h:t)
  | even h    = h `div` 2 : t'
  | otherwise = t'
  where t' = semiPareRecEq t

reverse2 [] = []
reverse2 (x:xs) = (reverse2 xs) ++ [x]

myreplicate :: Integer -> a -> [a]
myreplicate n v = undefined

---------------------------------------------
----------DESCRIERI DE LISTE ----------------
---------------------------------------------
semiPareComp :: [Int] -> [Int]
semiPareComp l = [ x `div` 2 | x <- l, even x ]



inIntervalRec :: Int -> Int -> [Int] -> [Int]
inIntervalRec lo hi xs = undefined

inIntervalComp :: Int -> Int -> [Int] -> [Int]
inIntervalComp lo hi xs = undefined



pozitiveRec :: [Int] -> Int
pozitiveRec l = undefined


pozitiveComp :: [Int] -> Int
pozitiveComp l = undefined


multDigitsRec :: String -> Int
multDigitsRec sir = undefined

multDigitsComp :: String -> Int
multDigitsComp sir = undefined


discountRec :: [Float] -> [Float]
discountRec list = undefined

discountComp :: [Float] -> [Float]
discountComp list = undefined


pozitiiImpareRec :: [Int] -> [Int]
pozitiiImpareRec l = undefined


pozitiiImpareComp :: [Int] -> [Int]
pozitiiImpareComp l = undefined

