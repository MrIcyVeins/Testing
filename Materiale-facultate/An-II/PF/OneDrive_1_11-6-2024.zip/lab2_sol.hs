-- la nevoie decomentati liniile urmatoare:

import Data.Char 
-- import Data.List

f1 = (^2) 
g1 x y = f1 x + f1 y



tridrept :: Integer -> Integer -> Integer -> Bool
tridrept x y z 
    | (^2) x + (^2) y == (^2) z = True
    | (^2) x + (^2) z == (^2) y = True
    | (^2) z + (^2) y == (^2) x = True
    | otherwise = False

f = (^2)

g :: Integer -> Integer -> Integer -> String
g a b c 
    | f a + f b == f c = "da, a^2 + b^2 = c^2"
    | f a + f c == f b = "da, a^2 + c^2 = b^2"
    | f b + f c == f a = "da, b^2 + c^2 = b^2"
    | otherwise = "nu"


-- poly a b c x = a * f x + b * x + c

-- eeny :: Integer -> String
-- eeny = undefined

-- fizzbuzz :: Integer -> String
-- fizzbuzz = undefined

-- poly :: Double -> Double -> Double -> Double -> Double
-- poly a b c x = a * x^2 + b * x + c

eeny :: Integer -> String
eeny x
 | x `mod` 2 == 0 = "eeny"
 | otherwise = "meeny"
 
eeny2 :: Integer -> String 
eeny2 x = if even x then "eeny" else "meeny"

check :: Integer -> String
check n
    | even n = "eeny"
    | odd n = "meeny"

poly :: Double -> Double -> Double -> Double -> Double
poly  a b c x = a * x^2  + b * x + c
    
check2 :: Integer -> String
check2 n
    | even n = "eeny"
    | otherwise = "meeny"
-- daca comentam otherwise : "*** Exception: lab2sol.hs:(53,1)-(54,21): Non-exhaustive patterns in function check2

fizzbuzz :: Integer -> String
fizzbuzz x
  | x `mod` 3 == 0 && x `mod` 5 == 0 = "FizzBuzz"
  | x `mod` 3 == 0 = "Fizz"
  | x `mod` 5 == 0 = "Buzz"
-- | otherwise = "" 


fizzbuzz2 :: Integer -> [Char]
fizzbuzz2 x 
    | mod x 3 == 0 && mod x 5 == 0 = "FizzBuzz"
    | mod x 3 == 0 = "Fizz"
    | mod x 5 == 0 = "Buzz"
    | otherwise = ""

fizzbuzz3 :: Integer -> String
fizzbuzz3 n = if (n `mod` 3 == 0) && (n `mod` 5 == 0) then "FizzBuzz"
             else if (n `mod` 5 == 0) then "Fizz"
             else if (n `mod` 3 == 0) then "Buzz"
             else ""

fb :: Int -> String
fb x
  | (mod x 3 == 0 && mod x 5 == 0) = f ++ b
  | (mod x 3 == 0) = f
  | (mod x 5 == 0) = b
  | otherwise = ""
  where f = "Fizz"
        b = "Buzz"
        
---------------------------------------------
-------RECURSIE: FIBONACCI-------------------
---------------------------------------------

fibonacciCazuri :: Integer -> Integer
fibonacciCazuri n
  | n < 2     = n
  | otherwise = fibonacciCazuri (n - 1) + fibonacciCazuri (n - 2)

fibonacciEcuational :: Integer -> Integer
fibonacciEcuational 0 = 0
fibonacciEcuational 1 = 1
fibonacciEcuational n =
    fibonacciEcuational (n - 1) + fibonacciEcuational (n - 2)

{-| @fibonacciLiniar@ calculeaza @F(n)@, al @n@-lea element din secvența
Fibonacci în timp liniar, folosind funcția auxiliară @fibonacciPereche@ care,
dat fiind @n >= 1@ calculează perechea @(F(n-1), F(n))@, evitănd astfel dubla
recursie. Completați definiția funcției fibonacciPereche.

Indicație:  folosiți matching pe perechea calculată de apelul recursiv.
-}
{-
fibonacciLiniar :: Integer -> Integer
fibonacciLiniar 0 = 0
fibonacciLiniar n = snd (fibonacciPereche n)
  where
    fibonacciPereche :: Integer -> (Integer, Integer)
    fibonacciPereche 1 = (0, 1)
    fibonacciPereche n = (b, a+b)
        where
            (a, b) = fibonacciPereche (n-1)-}


tribonacciCazuri :: Integer -> Integer
tribonacciCazuri  n
    | n <= 2 = 1
    | n == 3 = 2
    | n > 3 = tribonacciCazuri (n-1) + tribonacciCazuri (n-2) + tribonacciCazuri (n-3)
    
tribonacciEcuational :: Integer -> Integer
tribonacciEcuational  1 = 1
tribonacciEcuational  2 = 1
tribonacciEcuational  3 = 2
tribonacciEcuational  n = tribonacciCazuri (n-1) + tribonacciCazuri (n-2) + tribonacciCazuri (n-3)

tribonacciLiniar :: Integer -> Integer
tribonacciLiniar 1 = 1
tribonacciLiniar 2 = 1
tribonacciLiniar n =  snd ( snd (tribonacciPereche n))
  where
    tribonacciPereche :: Integer -> (Integer, (Integer, Integer))
    tribonacciPereche 3 = (1, (1, 2))
    tribonacciPereche n = (b, (c, a+b+c))
        where
            (a, (b, c)) = tribonacciPereche (n-1)




binomial :: Integer -> Integer -> Integer
binomial n 0 = 1
binomial 0 k = 0
binomial n k = binomial (n-1) k + binomial (n-1) (k-1)

bn :: Integer -> Integer -> Integer
bn n k
 -- | n == 0 && k == 0 = 1
  | k == 0 = 1  -- atentie la ordinea garzilor
  | n == 0 = 0
  | otherwise = bn (n - 1) k + bn (n - 1) (k - 1)
  
g2 :: Int -> Bool
g2 x = x > 0

--f2 :: Int -> Int
f2 x = x + 1
