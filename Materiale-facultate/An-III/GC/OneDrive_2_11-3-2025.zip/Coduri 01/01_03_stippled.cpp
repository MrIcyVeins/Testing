#include <windows.h>
#include <gl/freeglut.h>

 

void init (void)
{
	glClearColor (1.0, 1.0, 1.0, 0.5);
	glMatrixMode (GL_PROJECTION);
	gluOrtho2D (0.0, 800.0, 0.0, 600.0); 
}
void desen (void)
{   
	int i;
	GLfloat size=1;
	GLdouble incred=0.1;

		glClear (GL_COLOR_BUFFER_BIT);

		// la cota 100 
		// glEnable (GL_LINE_STIPPLE);
		glLineStipple (1, 0xF0F0);
		glLineWidth (1.0);
	    glBegin (GL_LINES); // linie intrerupta
		glColor3d (0.9, 0.0, 0.3);
	    glVertex2i (1, 100); 
		glVertex2i (200, 100);
		glEnd ( );
		glLineStipple (1, 0x1010);
		glBegin (GL_LINES); // linie punctata
		glColor3d (0.9, 0.0, 0.5);
	    glVertex2i (201, 100); 
		glVertex2i (400, 100);
		glEnd ( );
		glLineStipple (2, 0x1010);
		glBegin (GL_LINES); //  
		glColor3d (0.9, 0.0, 0.5);
	    glVertex2i (401, 100); 
		glVertex2i (600, 100);
		glEnd ( );
		glLineStipple (1, 0x1C71);
		glBegin (GL_LINES); // linie intrerupta
		glColor3d (1.0, 0.0, 0.8);
	    glVertex2i (601, 100); 
		glVertex2i (800, 100);
		glEnd ( );
		glDisable (GL_LINE_STIPPLE);

		// la cota 200 
		glEnable (GL_LINE_STIPPLE);
		glLineStipple (1, 0xF0F0);
		glLineWidth (5.0);
	    glBegin (GL_LINES); //  
		glColor3d (0.9, 0.0, 0.3);
	    glVertex2i (1, 200); 
		glVertex2i (200, 200);
		glEnd ( );
		glLineStipple (1, 0x1010);
		glBegin (GL_LINES); // linie punctata
		glColor3d (0.9, 0.0, 0.5);
	    glVertex2i (201, 200); 
		glVertex2i (400, 200);
		glEnd ( );
		glLineStipple (2, 0x1010);
		glBegin (GL_LINES); //  
		glColor3d (0.9, 0.0, 0.5);
	    glVertex2i (401, 200); 
		glVertex2i (600, 200);
		glEnd ( );
		glLineStipple (1, 0x1C71);
		glBegin (GL_LINES); //  
		glColor3d (1.0, 0.0, 0.8);
	    glVertex2i (601, 200); 
		glVertex2i (800, 200);
		glEnd ( );
		glDisable (GL_LINE_STIPPLE);

// la cota 300 
		glEnable (GL_LINE_STIPPLE);
		glLineStipple (1, 0x2727);
		glLineWidth (6.0);
	    glBegin (GL_LINES); //  
		glColor3d (0.1, 0.0, 0.3);
	    glVertex2i (1, 300); 
		glVertex2i (400, 300);
		glEnd ( );
		glLineStipple (2, 0x07BB);
		glLineWidth (9.0);
		glBegin (GL_LINES); //  
		glColor3d (0.3, 0.0, 0.1);
	    glVertex2i (401, 300); 
		glVertex2i (800, 300);
		glEnd ( );
		glDisable (GL_LINE_STIPPLE);

		//la cota 400
	for (i=0; i<400; i+=40)
	{
		glPointSize (size);
		glBegin (GL_POINTS);
		glColor3d (incred, 0.0, 0.0);
		glVertex2i (i, 400);
		glEnd ( );
		size+=2;
		incred+=0.1;
	}
	
		glLineWidth (1.0);
		glColor3d (0.0, 1.0, 0.0);
		glBegin (GL_LINES);
		glVertex2i (0, 400);
		glVertex2i (600, 400);
		glEnd ( );

		// la cota 500
		//glShadeModel(GL_FLAT);
		glLineWidth (4.0);
		glBegin (GL_LINES);
		glColor3d (0.0, 0.0, 1.0);
		glVertex2i (0, 500);
		glColor3d (1.0, 0.0, 0.0);
		glVertex2i (600, 500);
		glEnd ( );

	glFlush ( );
	 
}
void main (int argc, char**argv)
{
	glutInit (&argc, argv);
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize (800, 600);
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("Atribute ale punctelor si segmentelor");
	init ( );
	glutDisplayFunc (desen);
	glutMainLoop ( );
}