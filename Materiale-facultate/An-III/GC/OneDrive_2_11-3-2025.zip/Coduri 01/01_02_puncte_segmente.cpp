#include <windows.h>  // sunt mentionate fisiere (biblioteci) care urmeaza sa fie incluse 
#include <gl/freeglut.h> // nu trebuie uitat freeglut.h (sau glut.h sau gl.h & glu.h)

void init(void)  // initializare fereastra de vizualizare
{
	glClearColor(1.0, 1.0, 1.0, 0.0); // precizeaza culoarea de fond a ferestrei de vizualizare
	glMatrixMode(GL_PROJECTION);  // se precizeaza este vorba de o reprezentare 2D, realizata prin proiectie ortogonala
	gluOrtho2D(0.0, 1200.0, 0.0, 800.0); // sunt indicate coordonatele extreme ale ferestrei de vizualizare
}

void desen(void) // procedura desenare  
{
	// (1) PUNCTE
	// punctele albastre
	glColor3f(0.0, 0.0, 1.0);
	// glPointSize (10.0); 
	glBegin(GL_POINTS); // reprezinta puncte 
		glVertex2i(20, 20);
		glVertex2i(21, 21);
		glVertex2i(22, 22);
		glVertex2i(23, 23);
		glVertex2i(24, 24);
		glVertex2i(27, 27);
		glVertex2i(100, 100);
	glEnd();
	// punctele cu culori diferite
	// glEnable(GL_POINT_SMOOTH);
	glPointSize(6.0);
	glBegin(GL_POINTS);
		glColor3d(0.0, 0.05, 0.05);
		glVertex2i(100, 400);
		glColor3f(1.0, 0.0, 0.5);
		glVertex2i(300, 500);
	glEnd();
	//glDisable(GL_POINT_SMOOTH);

	// (2) SEGMENTE DE DREAPTA
	glShadeModel(GL_FLAT); 
	// primul segment
	glLineWidth(10.0);
	// glEnable(GL_LINE_STIPPLE);
	// glLineStipple(1, 0x1EED);
	glBegin(GL_LINES);
		glColor3f(1.0, 0.0, 0.0); // rosu
		glVertex2i(0, 100);
		glColor3f(1.0, 1.0, 0.0); // galben
		glVertex2i(400, 500);
	glEnd();
	glDisable(GL_LINE_STIPPLE);
	// o reuniune de segmente
	//glShadeModel(GL_SMOOTH);
	glLineWidth(6.0);
	glBegin(GL_LINE_LOOP); // reprezinta o reuniune de segmente
		glColor3f(1.0, 0.0, 0.0); // rosu
		glVertex2i(400, 400);
		glColor3f(0.0, 1.0, 0.0); // verde
		glVertex2i(600, 500);
		glColor3f(0.0, 0.0, 1.0); // albastru
		glVertex2i(700, 520);
		glColor3f(0.0, 1.0, 1.0); // turcoaz
		glVertex2i(655, 690);
	glEnd();
	glFlush(); // proceseaza procedurile OpenGL cat mai rapid
}
void main(int argc, char** argv)
{
	glutInit(&argc, argv); // initializare GLUT
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // se utilizeaza un singur buffer | modul de colorare RedGreenBlue (= default)
	glutInitWindowPosition(100, 100); // pozitia initiala a ferestrei de vizualizare (in coordonate ecran)
	glutInitWindowSize(900, 600); // dimensiunile ferestrei 
	glutCreateWindow("Puncte & Segmente"); // creeaza fereastra, indicand numele ferestrei de vizualizare - apare in partea superioara
	init(); // executa procedura de initializare
	glClear(GL_COLOR_BUFFER_BIT); // reprezentare si colorare fereastra de vizualizare
	glutDisplayFunc(desen); // procedura desen este invocata ori de cate ori este nevoie
	glutMainLoop(); // ultima instructiune a programului, asteapta (eventuale) noi date de intrare
}
/*
Modificari de testat
	1. PointSize (L.16)
	2. PointSmooth (L.27)
	3. ShadeModel (L.51)
	4. LineStipple (L41)
*/
